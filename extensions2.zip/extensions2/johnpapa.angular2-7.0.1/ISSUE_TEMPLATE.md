> Please provide us with the following information:
> ---------------------------------------------------------------

### OS and Version?
> Windows 7, 8 or 10. Linux (which distribution).macOS(Yosemite ? El Capitan? Sierra ?)

### Versions
  >

### Repro steps
  >

### The log given by the failure.
>

### Mention any other details that might be useful.

> ---------------------------------------------------------------
> Thanks! We'll be in touch soon.
