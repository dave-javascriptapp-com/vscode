## Angular Switcher Changelog

<a name="0.1.8"></a>

# 0.1.8 (2018-06-16)

* F12 open 2 definitions like Peek view ([#2](https://github.com/infinity1207/angular2-switcher/issues/2))

<a name="0.1.7"></a>

# 0.1.7 (2018-05-05)

* Add configuration to enable open files side by side.
    * Extension will add configuration "angular2-switcher.openSideBySide" to workspace, default value is `false`.
    * Add `"angular2-switcher.openSideBySide":true` in user settings to open template and styles etc side by side to the component class.