# vscode-icons

same as [vscode-icons/vscode-icons](https://github.com/vscode-icons/vscode-icons) but with mac folder icon.

### preview

![](https://raw.githubusercontent.com/wayou/vscode-icons/master/images/preview.png)
